$(document).ready(function(){

	/* ANIMATE SCROLL */
	window.sr = new scrollReveal();
	
});